#include <string>
#include <fstream>
#include "lexer.h"
using namespace std;

#ifndef globals_h
#define globals_h

extern string outputFile;
extern vector<string> allWords;
extern unsigned tokenIndex;

#endif /* globals_h */
